# Car-Parking-Simulation-using-OpenGL
This project creates a virtual car parking using OpenGL allowing users to explore the parking area, view cars closely, and drive and park a car. Cars and houses are modeled using OpenGL primitives like GL_LINES, GL_POLYGON, and GL_QUADS.
